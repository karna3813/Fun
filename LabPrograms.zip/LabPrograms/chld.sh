echo hello from child
